﻿using DAL;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SimuladoDAWPP
{
    public partial class CadastroNoticia : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CarregarNoticias();
            }
        }

        public void CarregarNoticias()
        {
            NoticiaDAL nDAL = new NoticiaDAL();

            gvNoticias.DataSource = nDAL.SelecionarTodos();
            gvNoticias.DataBind();
        }

        protected void btnInserir_Click(object sender, EventArgs e)
        {
            Noticia objNoticia = new Noticia();
            objNoticia.DsTitulo = txtTitulo.Text;
            objNoticia.DtNoticia = Convert.ToDateTime(txtData.Text);
            objNoticia.DsNoticia = txtNoticia.Text;

            NoticiaDAL nDAL = new NoticiaDAL();
            nDAL.InserirNoticia(objNoticia);
        }
    }
}