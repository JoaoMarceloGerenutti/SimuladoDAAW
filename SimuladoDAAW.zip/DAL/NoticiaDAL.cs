﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class NoticiaDAL
    {
        //Fazer o código para acessar o banco de dados
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BDSimuladoDAAW;Integrated Security=True";

        public void InserirNoticia(Noticia objNoticia)
        {

            //Cria um objeto de conexão com o banco de dados
            SqlConnection conn = new SqlConnection(connectionString);

            //Abre a conexão criada
            conn.Open();

            //Criar o comando para execução
            string sql = "INSERT INTO Noticias VALUES (@dsTitulo, @dtNoticia, @dsNoticia)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            //Definir os parâmetros
            cmd.Parameters.AddWithValue("@dsTitulo", objNoticia.DsTitulo);
            cmd.Parameters.AddWithValue("@dtNoticia", objNoticia.DtNoticia);
            cmd.Parameters.AddWithValue("@dsNoticia", objNoticia.DsNoticia);

            //Executar o comando
            cmd.ExecuteNonQuery();

            //Fechar a conexão
            conn.Close();
        }

        public List<Noticia> SelecionarTodos()
        {
            List<Noticia> listaNoticias = new List<Noticia>();

            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string sql = "SELECT * FROM Noticias";
            SqlCommand cmd = new SqlCommand(sql, conn);

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                Noticia objNoticia;
                while (dr.Read())
                {
                    objNoticia = new Noticia();
                    objNoticia.CdNoticia = Convert.ToInt32(dr["CdNoticia"]);
                    objNoticia.DsTitulo = dr["DsTitulo"].ToString();
                    objNoticia.DtNoticia = Convert.ToDateTime(dr["DtNoticia"]);
                    objNoticia.DsNoticia = dr["DsNoticia"].ToString();

                    listaNoticias.Add(objNoticia);
                }
            }

            conn.Close();

            return listaNoticias;
        }
    }
}
