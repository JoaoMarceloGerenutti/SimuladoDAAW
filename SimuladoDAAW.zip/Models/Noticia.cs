﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Noticia
    {
        public int CdNoticia { get; set; }
        public string DsTitulo { get; set; }
        public DateTime DtNoticia { get; set; }
        public string DsNoticia { get; set; }
    }
}
